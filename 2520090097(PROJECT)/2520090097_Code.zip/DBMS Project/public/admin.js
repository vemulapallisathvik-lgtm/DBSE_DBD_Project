// ============================================================
// ADMIN FACE REGISTRATION
// ============================================================

let cameraStream = null;

let modelsLoaded = false;


// ============================================================
// ELEMENTS
// ============================================================

const video =
    document.getElementById("video");

const startCameraButton =
    document.getElementById(
        "startCameraButton"
    );

const captureButton =
    document.getElementById(
        "captureButton"
    );

const stopCameraButton =
    document.getElementById(
        "stopCameraButton"
    );

const cameraStatus =
    document.getElementById(
        "cameraStatus"
    );

const registerStatus =
    document.getElementById(
        "registerStatus"
    );


// ============================================================
// PAGE START
// ============================================================

document.addEventListener(
    "DOMContentLoaded",
    async function() {

        await loadFaceModels();

        await loadDashboard();

    }
);


// ============================================================
// LOAD FACE API MODELS
// ============================================================

async function loadFaceModels() {

    try {

        cameraStatus.innerText =
            "Loading face recognition models...";


        await faceapi.nets.tinyFaceDetector.loadFromUri(
            "/models"
        );


        await faceapi.nets.faceLandmark68Net.loadFromUri(
            "/models"
        );


        await faceapi.nets.faceRecognitionNet.loadFromUri(
            "/models"
        );


        modelsLoaded = true;


        cameraStatus.innerText =
            "✅ Face recognition models loaded. Camera is ready.";

        cameraStatus.style.color =
            "green";


        console.log(
            "Face recognition models loaded."
        );

    } catch (error) {

        console.error(
            "Model loading error:",
            error
        );


        cameraStatus.innerText =
            "❌ Could not load face recognition models. Check the public/models folder.";

        cameraStatus.style.color =
            "red";

    }

}


// ============================================================
// START CAMERA
// ============================================================

startCameraButton.addEventListener(
    "click",
    startCamera
);


async function startCamera() {

    if (!modelsLoaded) {

        alert(
            "Face recognition models are still loading. Please wait."
        );

        return;

    }


    try {

        if (cameraStream) {

            stopCamera();

        }


        cameraStatus.innerText =
            "Requesting camera permission...";

        cameraStatus.style.color =
            "orange";


        cameraStream =
            await navigator.mediaDevices.getUserMedia({

                video: {

                    facingMode: "user",

                    width: {
                        ideal: 640
                    },

                    height: {
                        ideal: 480
                    }

                },

                audio: false

            });


        video.srcObject =
            cameraStream;


        await video.play();


        cameraStatus.innerText =
            "✅ Camera started. Position one face inside the camera.";

        cameraStatus.style.color =
            "green";


        console.log(
            "Camera started."
        );

    } catch (error) {

        console.error(
            error
        );


        cameraStatus.style.color =
            "red";


        if (
            error.name ===
            "NotAllowedError"
        ) {

            cameraStatus.innerText =
                "❌ Camera permission denied. Allow camera access in the browser.";

        } else if (
            error.name ===
            "NotFoundError"
        ) {

            cameraStatus.innerText =
                "❌ No camera found.";

        } else if (
            error.name ===
            "NotReadableError"
        ) {

            cameraStatus.innerText =
                "❌ Camera is being used by another application.";

        } else {

            cameraStatus.innerText =
                "❌ Camera error: " +
                error.message;

        }

    }

}


// ============================================================
// STOP CAMERA
// ============================================================

stopCameraButton.addEventListener(
    "click",
    stopCamera
);


function stopCamera() {

    if (cameraStream) {

        cameraStream
            .getTracks()
            .forEach(
                track => track.stop()
            );

    }


    cameraStream =
        null;


    video.srcObject =
        null;


    cameraStatus.innerText =
        "Camera stopped.";

    cameraStatus.style.color =
        "gray";

}


// ============================================================
// CAPTURE + REGISTER
// ============================================================

captureButton.addEventListener(
    "click",
    registerStudent
);


async function registerStudent() {

    registerStatus.innerText =
        "";


    // ========================================================
    // GET INPUT
    // ========================================================

    const name =
        document
        .getElementById("studentName")
        .value
        .trim();


    const section =
        document
        .getElementById("studentSection")
        .value
        .trim();


    const rollNumber =
        document
        .getElementById("rollNumber")
        .value
        .trim();


    // ========================================================
    // VALIDATION
    // ========================================================

    if (!name) {

        registerStatus.innerText =
            "❌ Enter student name.";

        registerStatus.style.color =
            "red";

        return;

    }


    if (!section) {

        registerStatus.innerText =
            "❌ Enter section.";

        registerStatus.style.color =
            "red";

        return;

    }


    if (!rollNumber) {

        registerStatus.innerText =
            "❌ Enter roll number.";

        registerStatus.style.color =
            "red";

        return;

    }


    if (!cameraStream) {

        registerStatus.innerText =
            "❌ Start the camera first.";

        registerStatus.style.color =
            "red";

        return;

    }


    // ========================================================
    // DETECT FACE
    // ========================================================

    registerStatus.innerText =
        "Detecting face...";

    registerStatus.style.color =
        "orange";


    try {

        const detection =
            await faceapi
            .detectSingleFace(
                video,
                new faceapi.TinyFaceDetectorOptions({
                    inputSize: 416,
                    scoreThreshold: 0.5
                })
            )
            .withFaceLandmarks()
            .withFaceDescriptor();


        // ====================================================
        // NO FACE
        // ====================================================

        if (!detection) {

            registerStatus.innerText =
                "❌ No face detected. Look directly at the camera.";

            registerStatus.style.color =
                "red";

            return;

        }


        // ====================================================
        // FACE FOUND
        // ====================================================

        const descriptor =
            Array.from(
                detection.descriptor
            );


        console.log(
            "Face descriptor:",
            descriptor
        );


        // ====================================================
        // SEND TO SERVER
        // ====================================================

        registerStatus.innerText =
            "Saving student...";


        const response =
            await fetch(
                "/api/register", {

                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({

                        name: name,

                        section: section,

                        rollNumber: rollNumber,

                        faceDescriptor: descriptor

                    })

                }
            );


        if (
            response.status === 401
        ) {

            window.location.href =
                "login.html";

            return;

        }


        const result =
            await response.json();


        if (
            result.success
        ) {

            registerStatus.innerText =
                "✅ Student registered successfully!";

            registerStatus.style.color =
                "green";


            // Clear form

            document
                .getElementById(
                    "studentName"
                )
                .value = "";


            document
                .getElementById(
                    "studentSection"
                )
                .value = "";


            document
                .getElementById(
                    "rollNumber"
                )
                .value = "";


            await loadDashboard();

        } else {

            registerStatus.innerText =
                "❌ " +
                (
                    result.message ||
                    "Registration failed."
                );

            registerStatus.style.color =
                "red";

        }

    } catch (error) {

        console.error(
            "Registration error:",
            error
        );


        registerStatus.innerText =
            "❌ " +
            error.message;

        registerStatus.style.color =
            "red";

    }

}


// ============================================================
// LOAD DASHBOARD
// ============================================================

async function loadDashboard() {

    try {

        const response =
            await fetch(
                "/api/dashboard"
            );


        if (
            response.status === 401
        ) {

            window.location.href =
                "login.html";

            return;

        }


        const data =
            await response.json();


        if (!data.success) {

            return;

        }


        document
            .getElementById(
                "totalStudents"
            )
            .innerText =
            data.totalStudents;


        document
            .getElementById(
                "presentToday"
            )
            .innerText =
            data.presentToday;


        document
            .getElementById(
                "absentToday"
            )
            .innerText =
            data.absentToday;


        displayPresentStudents(
            data.presentStudents
        );


        loadAttendance();

    } catch (error) {

        console.error(
            "Dashboard error:",
            error
        );

    }

}


// ============================================================
// PRESENT STUDENTS
// ============================================================

function displayPresentStudents(
    students
) {

    const container =
        document.getElementById(
            "presentStudents"
        );


    if (!students ||
        students.length === 0
    ) {

        container.innerHTML = `

            <div class="empty">
                No students are present today.
            </div>

        `;

        return;

    }


    let html = `

        <table>

            <thead>

                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Section</th>
                    <th>Roll Number</th>
                    <th>Time</th>
                </tr>

            </thead>

            <tbody>

    `;


    students.forEach(
        (student, index) => {

            html += `

                <tr>

                    <td>
                        ${index + 1}
                    </td>

                    <td class="student-name">
                        ${escapeHTML(
                            student.name
                        )}
                    </td>

                    <td>
                        ${escapeHTML(
                            student.section
                        )}
                    </td>

                    <td>
                        ${escapeHTML(
                            student.roll_number
                        )}
                    </td>

                    <td>
                        ${escapeHTML(
                            student.time
                        )}
                    </td>

                </tr>

            `;

        }
    );


    html += `
            </tbody>
        </table>
    `;


    container.innerHTML =
        html;

}


// ============================================================
// ALL ATTENDANCE
// ============================================================

async function loadAttendance() {

    const container =
        document.getElementById(
            "attendanceTable"
        );


    try {

        const response =
            await fetch(
                "/api/attendance"
            );


        if (
            response.status === 401
        ) {

            window.location.href =
                "login.html";

            return;

        }


        const data =
            await response.json();


        if (!data.success ||
            data.attendance.length === 0
        ) {

            container.innerHTML = `

                <div class="empty">
                    No attendance records.
                </div>

            `;

            return;

        }


        let html = `

            <table>

                <thead>

                    <tr>
                        <th>Name</th>
                        <th>Section</th>
                        <th>Roll Number</th>
                        <th>Date</th>
                        <th>Time</th>
                    </tr>

                </thead>

                <tbody>

        `;


        data.attendance.forEach(
            record => {

                html += `

                    <tr>

                        <td class="student-name">
                            ${escapeHTML(
                                record.name
                            )}
                        </td>

                        <td>
                            ${escapeHTML(
                                record.section
                            )}
                        </td>

                        <td>
                            ${escapeHTML(
                                record.roll_number
                            )}
                        </td>

                        <td>
                            ${escapeHTML(
                                record.date
                            )}
                        </td>

                        <td>
                            ${escapeHTML(
                                record.time
                            )}
                        </td>

                    </tr>

                `;

            }
        );


        html += `

                </tbody>

            </table>

        `;


        container.innerHTML =
            html;

    } catch (error) {

        console.error(
            error
        );

    }

}


// ============================================================
// HTML ESCAPE
// ============================================================

function escapeHTML(value) {

    const div =
        document.createElement("div");

    div.textContent =
        value === null ||
        value === undefined ?
        "" :
        value;

    return div.innerHTML;

}


// ============================================================
// LOGOUT
// ============================================================

document
    .getElementById("logoutButton")
    .addEventListener(
        "click",
        async function() {

            await fetch(
                "/api/admin/logout", {
                    method: "POST"
                }
            );


            window.location.href =
                "login.html";

        }
    );