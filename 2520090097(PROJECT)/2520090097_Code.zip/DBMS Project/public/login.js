document.addEventListener("DOMContentLoaded", function() {

    const loginForm = document.getElementById("loginForm");
    const loginButton = document.getElementById("loginButton");
    const message = document.getElementById("message");

    loginForm.addEventListener("submit", async function(event) {

        event.preventDefault();

        const username =
            document.getElementById("username").value.trim();

        const password =
            document.getElementById("password").value;

        if (!username || !password) {

            message.textContent =
                "Please enter username and password.";

            message.style.color = "red";

            return;
        }

        loginButton.disabled = true;
        loginButton.textContent = "Logging in...";

        message.textContent = "";

        try {

            const response = await fetch("/api/login", {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                credentials: "include",

                body: JSON.stringify({
                    username: username,
                    password: password
                })
            });

            const data = await response.json();

            if (response.ok && data.success) {

                message.textContent =
                    "Login successful!";

                message.style.color = "green";

                sessionStorage.setItem(
                    "adminLoggedIn",
                    "true"
                );

                setTimeout(function() {

                    window.location.href =
                        "/admin.html";

                }, 500);

            } else {

                message.textContent =
                    data.message ||
                    "Invalid username or password.";

                message.style.color = "red";

                loginButton.disabled = false;

                loginButton.textContent = "Login";
            }

        } catch (error) {

            console.error("Login error:", error);

            message.textContent =
                "Cannot connect to the server.";

            message.style.color = "red";

            loginButton.disabled = false;

            loginButton.textContent = "Login";
        }

    });

});