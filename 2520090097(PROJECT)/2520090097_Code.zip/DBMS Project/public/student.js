// ============================================================
// STUDENT FACE RECOGNITION ATTENDANCE
// ============================================================

let cameraStream = null;

let modelsLoaded = false;


// ============================================================
// ELEMENTS
// ============================================================

const video =
    document.getElementById("video");

const startCameraButton =
    document.getElementById(
        "startCameraButton"
    );

const markAttendanceButton =
    document.getElementById(
        "markAttendanceButton"
    );

const stopCameraButton =
    document.getElementById(
        "stopCameraButton"
    );

const cameraStatus =
    document.getElementById(
        "cameraStatus"
    );

const attendanceStatus =
    document.getElementById(
        "attendanceStatus"
    );


// ============================================================
// LOAD PAGE
// ============================================================

document.addEventListener(
    "DOMContentLoaded",
    async function() {

        await loadModels();

    }
);


// ============================================================
// LOAD FACE MODELS
// ============================================================

async function loadModels() {

    try {

        cameraStatus.innerText =
            "Loading face recognition models...";


        await faceapi.nets.tinyFaceDetector.loadFromUri(
            "/models"
        );


        await faceapi.nets.faceLandmark68Net.loadFromUri(
            "/models"
        );


        await faceapi.nets.faceRecognitionNet.loadFromUri(
            "/models"
        );


        modelsLoaded = true;


        cameraStatus.innerText =
            "✅ Models loaded. Camera is ready.";

        cameraStatus.style.color =
            "green";


    } catch (error) {

        console.error(
            error
        );


        cameraStatus.innerText =
            "❌ Could not load face recognition models. Check public/models.";

        cameraStatus.style.color =
            "red";

    }

}


// ============================================================
// START CAMERA
// ============================================================

startCameraButton.addEventListener(
    "click",
    startCamera
);


async function startCamera() {

    if (!modelsLoaded) {

        alert(
            "Face recognition models are still loading."
        );

        return;

    }


    try {

        if (cameraStream) {

            stopCamera();

        }


        cameraStatus.innerText =
            "Requesting camera permission...";


        cameraStream =
            await navigator.mediaDevices.getUserMedia({

                video: {

                    facingMode: "user",

                    width: {
                        ideal: 640
                    },

                    height: {
                        ideal: 480
                    }

                },

                audio: false

            });


        video.srcObject =
            cameraStream;


        await video.play();


        cameraStatus.innerText =
            "✅ Camera started. Look directly at the camera.";

        cameraStatus.style.color =
            "green";


    } catch (error) {

        console.error(
            error
        );


        cameraStatus.style.color =
            "red";


        if (
            error.name ===
            "NotAllowedError"
        ) {

            cameraStatus.innerText =
                "❌ Camera permission denied.";

        } else if (
            error.name ===
            "NotFoundError"
        ) {

            cameraStatus.innerText =
                "❌ Camera not found.";

        } else {

            cameraStatus.innerText =
                "❌ Camera error: " +
                error.message;

        }

    }

}


// ============================================================
// STOP CAMERA
// ============================================================

stopCameraButton.addEventListener(
    "click",
    stopCamera
);


function stopCamera() {

    if (cameraStream) {

        cameraStream
            .getTracks()
            .forEach(
                track => track.stop()
            );

    }


    cameraStream =
        null;


    video.srcObject =
        null;


    cameraStatus.innerText =
        "Camera stopped.";

    cameraStatus.style.color =
        "gray";

}


// ============================================================
// MARK ATTENDANCE
// ============================================================

markAttendanceButton.addEventListener(
    "click",
    markAttendance
);


async function markAttendance() {

    attendanceStatus.innerText =
        "";


    if (!cameraStream) {

        attendanceStatus.innerText =
            "❌ Start the camera first.";

        attendanceStatus.style.color =
            "red";

        return;

    }


    if (!modelsLoaded) {

        attendanceStatus.innerText =
            "❌ Face recognition models are not loaded.";

        attendanceStatus.style.color =
            "red";

        return;

    }


    attendanceStatus.innerText =
        "🔍 Detecting face...";

    attendanceStatus.style.color =
        "orange";


    try {

        // ====================================================
        // DETECT FACE
        // ====================================================

        const detection =
            await faceapi
            .detectSingleFace(
                video,
                new faceapi.TinyFaceDetectorOptions({
                    inputSize: 416,
                    scoreThreshold: 0.5
                })
            )
            .withFaceLandmarks()
            .withFaceDescriptor();


        // ====================================================
        // NO FACE
        // ====================================================

        if (!detection) {

            attendanceStatus.innerText =
                "❌ No face detected. Look directly at the camera.";

            attendanceStatus.style.color =
                "red";

            return;

        }


        // ====================================================
        // CREATE 128-VALUE DESCRIPTOR
        // ====================================================

        const descriptor =
            Array.from(
                detection.descriptor
            );


        console.log(
            "Face descriptor generated:",
            descriptor.length,
            "values"
        );


        attendanceStatus.innerText =
            "🔍 Checking registered students...";


        // ====================================================
        // SEND DESCRIPTOR TO SERVER
        // ====================================================

        const response =
            await fetch(
                "/api/recognize", {

                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({

                        faceDescriptor: descriptor

                    })

                }
            );


        const result =
            await response.json();


        // ====================================================
        // FACE NOT RECOGNIZED
        // ====================================================

        if (
            response.status === 404
        ) {

            attendanceStatus.innerText =
                "❌ Face not recognized. Please contact the administrator.";

            attendanceStatus.style.color =
                "red";

            return;

        }


        // ====================================================
        // ALREADY PRESENT
        // ====================================================

        if (
            response.status === 409
        ) {

            attendanceStatus.innerText =
                "⚠️ " +
                result.message;

            attendanceStatus.style.color =
                "orange";


            if (result.student) {

                showStudent(
                    result.student
                );

            }

            return;

        }


        // ====================================================
        // OTHER ERROR
        // ====================================================

        if (!result.success) {

            attendanceStatus.innerText =
                "❌ " +
                (
                    result.message ||
                    "Attendance failed."
                );

            attendanceStatus.style.color =
                "red";

            return;

        }


        // ====================================================
        // SUCCESS
        // ====================================================

        attendanceStatus.innerText =
            "✅ Attendance marked successfully!";

        attendanceStatus.style.color =
            "green";


        showStudent(
            result.student
        );

    } catch (error) {

        console.error(
            "Attendance error:",
            error
        );


        attendanceStatus.innerText =
            "❌ Could not connect to server.";

        attendanceStatus.style.color =
            "red";

    }

}


// ============================================================
// SHOW STUDENT
// ============================================================

function showStudent(student) {

    const resultBox =
        document.getElementById(
            "studentResult"
        );


    document
        .getElementById(
            "recognizedName"
        )
        .innerText =
        student.name;


    document
        .getElementById(
            "recognizedSection"
        )
        .innerText =
        student.section;


    document
        .getElementById(
            "recognizedRoll"
        )
        .innerText =
        student.rollnumber;


    document
        .getElementById(
            "recognizedTime"
        )
        .innerText =
        student.time || "";


    resultBox.style.display =
        "block";

}