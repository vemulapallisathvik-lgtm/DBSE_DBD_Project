// ============================================================
// FACE RECOGNITION ATTENDANCE SYSTEM
// SERVER.JS
// ============================================================

const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const cors = require("cors");
const session = require("express-session");
const path = require("path");

const app = express();

const PORT = 3000;

// ============================================================
// ADMIN LOGIN DETAILS
// ============================================================

const ADMIN_USERNAME = "admin";
const ADMIN_PASSWORD = "admin123";

// ============================================================
// MIDDLEWARE
// ============================================================

app.use(cors({
    origin: true,
    credentials: true
}));

app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));

app.use(
    session({
        secret: "face-recognition-attendance-secret",
        resave: false,
        saveUninitialized: false,
        cookie: {
            secure: false,
            httpOnly: true,
            maxAge: 24 * 60 * 60 * 1000
        }
    })
);

// Serve files inside public folder
app.use(express.static(path.join(__dirname, "public")));

// ============================================================
// DATABASE
// ============================================================

const db = new sqlite3.Database(
    path.join(__dirname, "attendance.db"),
    (err) => {

        if (err) {
            console.error("Database connection error:", err.message);
        } else {
            console.log("Connected to SQLite database.");
        }

    }
);

// ============================================================
// CREATE TABLES
// ============================================================

db.serialize(() => {

    // STUDENTS TABLE
    db.run(`
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            section TEXT NOT NULL,
            roll_number TEXT NOT NULL UNIQUE,
            face_descriptor TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // ATTENDANCE TABLE
    db.run(`
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            section TEXT NOT NULL,
            roll_number TEXT NOT NULL,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(student_id, date),
            FOREIGN KEY(student_id) REFERENCES students(id)
        )
    `);

    console.log("Database tables ready.");

});

// ============================================================
// ADMIN LOGIN
// ============================================================

app.post("/api/login", (req, res) => {

    const username = req.body.username;
    const password = req.body.password;

    if (
        username === ADMIN_USERNAME &&
        password === ADMIN_PASSWORD
    ) {

        req.session.adminLoggedIn = true;
        req.session.username = username;

        return res.json({
            success: true,
            message: "Login successful"
        });

    }

    return res.status(401).json({
        success: false,
        message: "Invalid username or password"
    });

});

// ============================================================
// CHECK ADMIN LOGIN
// ============================================================

app.get("/api/check-admin", (req, res) => {

    if (req.session.adminLoggedIn) {

        return res.json({
            loggedIn: true,
            username: req.session.username
        });

    }

    return res.status(401).json({
        loggedIn: false
    });

});

// ============================================================
// ADMIN LOGOUT
// ============================================================

app.post("/api/logout", (req, res) => {

    req.session.destroy((err) => {

        if (err) {

            console.error("Logout error:", err);

            return res.status(500).json({
                success: false,
                message: "Logout failed"
            });

        }

        res.json({
            success: true,
            message: "Logged out successfully"
        });

    });

});

// ============================================================
// ADMIN AUTHENTICATION MIDDLEWARE
// ============================================================

function requireAdmin(req, res, next) {

    if (req.session.adminLoggedIn) {
        next();
        return;
    }

    return res.status(401).json({
        success: false,
        message: "Admin login required"
    });

}
// ============================================================
// ADMIN DASHBOARD
// ADMIN ONLY
// ============================================================

app.get("/api/dashboard", requireAdmin, (req, res) => {

    const today =
        new Date().toISOString().split("T")[0];

    // Get total number of registered students
    db.get(
        `
        SELECT COUNT(*) AS totalStudents
        FROM students
        `, [],
        (err, studentResult) => {

            if (err) {

                console.error(
                    "Dashboard student count error:",
                    err
                );

                return res.status(500).json({
                    success: false,
                    message: "Failed to load student count."
                });

            }

            const totalStudents =
                studentResult.totalStudents;


            // Get today's attendance
            db.all(
                `
                SELECT
                    student_id,
                    name,
                    section,
                    roll_number,
                    date,
                    time
                FROM attendance
                WHERE date = ?
                ORDER BY time ASC
                `, [today],

                (err, attendanceRows) => {

                    if (err) {

                        console.error(
                            "Dashboard attendance error:",
                            err
                        );

                        return res.status(500).json({
                            success: false,
                            message: "Failed to load attendance."
                        });

                    }


                    const presentToday =
                        attendanceRows.length;


                    const absentToday =
                        Math.max(
                            totalStudents - presentToday,
                            0
                        );


                    res.json({

                        success: true,

                        totalStudents: totalStudents,

                        presentToday: presentToday,

                        absentToday: absentToday,

                        presentStudents: attendanceRows

                    });

                }
            );

        }
    );

});

// ============================================================
// REGISTER STUDENT
// ============================================================

app.post("/api/register", requireAdmin, (req, res) => {

    const {
        name,
        section,
        rollNumber,
        faceDescriptor
    } = req.body;

    // Validate data
    if (!name ||
        !section ||
        !rollNumber ||
        !faceDescriptor
    ) {

        return res.status(400).json({
            success: false,
            message: "Please provide name, section, roll number and face data."
        });

    }

    // Convert face descriptor to JSON
    let descriptorString;

    try {

        if (typeof faceDescriptor === "string") {

            JSON.parse(faceDescriptor);
            descriptorString = faceDescriptor;

        } else {

            descriptorString = JSON.stringify(faceDescriptor);

        }

    } catch (error) {

        return res.status(400).json({
            success: false,
            message: "Invalid face descriptor."
        });

    }

    // Check if roll number already exists
    db.get(
        `SELECT * FROM students WHERE roll_number = ?`, [rollNumber],
        (err, existingStudent) => {

            if (err) {

                console.error(err);

                return res.status(500).json({
                    success: false,
                    message: "Database error."
                });

            }

            if (existingStudent) {

                return res.status(400).json({
                    success: false,
                    message: "A student with this roll number is already registered."
                });

            }

            // Insert student
            db.run(
                `
                INSERT INTO students
                (name, section, roll_number, face_descriptor)
                VALUES (?, ?, ?, ?)
                `, [
                    name.trim(),
                    section.trim(),
                    rollNumber.trim(),
                    descriptorString
                ],
                function(err) {

                    if (err) {

                        console.error(
                            "Student registration error:",
                            err.message
                        );

                        return res.status(500).json({
                            success: false,
                            message: "Failed to register student."
                        });

                    }

                    res.json({
                        success: true,
                        message: "Student registered successfully.",
                        studentId: this.lastID
                    });

                }
            );

        }
    );

});

// ============================================================
// GET ALL STUDENTS
// ADMIN ONLY
// ============================================================

app.get("/api/students", requireAdmin, (req, res) => {

    db.all(
        `
        SELECT
            id,
            name,
            section,
            roll_number,
            created_at
        FROM students
        ORDER BY name ASC
        `, [],
        (err, rows) => {

            if (err) {

                console.error(err);

                return res.status(500).json({
                    success: false,
                    message: "Failed to fetch students."
                });

            }

            res.json({
                success: true,
                students: rows
            });

        }
    );

});

// ============================================================
// GET TOTAL NUMBER OF STUDENTS
// ADMIN ONLY
// ============================================================

app.get("/api/student-count", requireAdmin, (req, res) => {

    db.get(
        `SELECT COUNT(*) AS total FROM students`, [],
        (err, row) => {

            if (err) {

                return res.status(500).json({
                    success: false,
                    message: "Failed to get student count."
                });

            }

            res.json({
                success: true,
                total: row.total
            });

        }
    );

});

// ============================================================
// DELETE ONE STUDENT
// ADMIN ONLY
// ============================================================

app.delete("/api/students/:id", requireAdmin, (req, res) => {

    const studentId = req.params.id;

    db.run(
        `DELETE FROM attendance WHERE student_id = ?`, [studentId],
        (err) => {

            if (err) {

                return res.status(500).json({
                    success: false,
                    message: "Failed to delete attendance records."
                });

            }

            db.run(
                `DELETE FROM students WHERE id = ?`, [studentId],
                function(err) {

                    if (err) {

                        return res.status(500).json({
                            success: false,
                            message: "Failed to delete student."
                        });

                    }

                    if (this.changes === 0) {

                        return res.status(404).json({
                            success: false,
                            message: "Student not found."
                        });

                    }

                    res.json({
                        success: true,
                        message: "Student deleted successfully."
                    });

                }
            );

        }
    );

});

// ============================================================
// DELETE ALL STUDENTS
// ADMIN ONLY
// ============================================================

app.delete("/api/students", requireAdmin, (req, res) => {

    db.serialize(() => {

        db.run(`DELETE FROM attendance`);

        db.run(
            `DELETE FROM students`,
            function(err) {

                if (err) {

                    return res.status(500).json({
                        success: false,
                        message: "Failed to delete students."
                    });

                }

                res.json({
                    success: true,
                    message: "All student data deleted successfully."
                });

            }
        );

    });

});

// ============================================================
// FACE RECOGNITION
// ============================================================
//
// Student's browser sends:
//
// {
//     "faceDescriptor": [128 face values]
// }
//
// The server compares it with registered students.
//
// ============================================================

function calculateFaceDistance(descriptor1, descriptor2) {

    if (!Array.isArray(descriptor1) ||
        !Array.isArray(descriptor2)
    ) {
        return Infinity;
    }

    if (descriptor1.length !== descriptor2.length) {
        return Infinity;
    }

    let sum = 0;

    for (let i = 0; i < descriptor1.length; i++) {

        const difference =
            Number(descriptor1[i]) -
            Number(descriptor2[i]);

        sum += difference * difference;

    }

    return Math.sqrt(sum);
}

// ============================================================
// RECOGNIZE FACE
// ============================================================

app.post("/api/recognize", (req, res) => {

    const { faceDescriptor } = req.body;

    if (!faceDescriptor) {

        return res.status(400).json({
            success: false,
            message: "Face descriptor is required."
        });

    }

    let currentDescriptor;

    try {

        if (typeof faceDescriptor === "string") {

            currentDescriptor = JSON.parse(faceDescriptor);

        } else {

            currentDescriptor = faceDescriptor;

        }

    } catch (error) {

        return res.status(400).json({
            success: false,
            message: "Invalid face descriptor."
        });

    }

    if (!Array.isArray(currentDescriptor)) {

        return res.status(400).json({
            success: false,
            message: "Invalid face descriptor format."
        });

    }

    // Get registered students
    db.all(
        `
        SELECT
            id,
            name,
            section,
            roll_number,
            face_descriptor
        FROM students
        `, [],
        (err, students) => {

            if (err) {

                console.error(err);

                return res.status(500).json({
                    success: false,
                    message: "Database error."
                });

            }

            if (students.length === 0) {

                return res.status(404).json({
                    success: false,
                    message: "No students are registered."
                });

            }

            let bestStudent = null;
            let bestDistance = Infinity;

            // Compare face with every registered student
            for (const student of students) {

                try {

                    const registeredDescriptor =
                        JSON.parse(student.face_descriptor);

                    const distance =
                        calculateFaceDistance(
                            currentDescriptor,
                            registeredDescriptor
                        );

                    if (distance < bestDistance) {

                        bestDistance = distance;
                        bestStudent = student;

                    }

                } catch (error) {

                    console.log(
                        "Invalid descriptor for student:",
                        student.name
                    );

                }

            }

            // ==================================================
            // FACE MATCH THRESHOLD
            // ==================================================

            // For face-api.js 128-value descriptors,
            // a value around 0.6 is commonly used.
            //
            // This value can be adjusted if required.

            const FACE_MATCH_THRESHOLD = 0.60;

            if (!bestStudent ||
                bestDistance > FACE_MATCH_THRESHOLD
            ) {

                return res.status(404).json({
                    success: false,
                    message: "Face not recognized. Please contact the administrator."
                });

            }

            // ==================================================
            // FACE RECOGNIZED
            // ==================================================

            const now = new Date();

            const date = now.toISOString().split("T")[0];

            const time =
                now.toLocaleTimeString("en-IN", {
                    hour: "2-digit",
                    minute: "2-digit",
                    second: "2-digit"
                });

            // Check whether attendance already marked today
            db.get(
                `
                SELECT *
                FROM attendance
                WHERE student_id = ?
                AND date = ?
                `, [
                    bestStudent.id,
                    date
                ],
                (err, existingAttendance) => {

                    if (err) {

                        console.error(err);

                        return res.status(500).json({
                            success: false,
                            message: "Attendance database error."
                        });

                    }

                    // Already marked
                    if (existingAttendance) {

                        return res.json({
                            success: true,
                            alreadyMarked: true,
                            message: `${bestStudent.name} is already marked present today.`,
                            student: {
                                id: bestStudent.id,
                                name: bestStudent.name,
                                section: bestStudent.section,
                                rollNumber: bestStudent.roll_number
                            },
                            distance: bestDistance
                        });

                    }

                    // Mark attendance
                    db.run(
                        `
                        INSERT INTO attendance
                        (
                            student_id,
                            name,
                            section,
                            roll_number,
                            date,
                            time
                        )
                        VALUES (?, ?, ?, ?, ?, ?)
                        `, [
                            bestStudent.id,
                            bestStudent.name,
                            bestStudent.section,
                            bestStudent.roll_number,
                            date,
                            time
                        ],
                        function(err) {

                            if (err) {

                                console.error(
                                    "Attendance insert error:",
                                    err.message
                                );

                                return res.status(500).json({
                                    success: false,
                                    message: "Failed to mark attendance."
                                });

                            }

                            res.json({
                                success: true,
                                alreadyMarked: false,
                                message: `Attendance marked successfully for ${bestStudent.name}.`,
                                student: {
                                    id: bestStudent.id,
                                    name: bestStudent.name,
                                    section: bestStudent.section,
                                    rollNumber: bestStudent.roll_number
                                },
                                date: date,
                                time: time,
                                distance: bestDistance
                            });

                        }
                    );

                }
            );

        }
    );

});

// ============================================================
// GET TODAY'S ATTENDANCE
// ADMIN ONLY
// ============================================================

app.get("/api/attendance/today", requireAdmin, (req, res) => {

    const today =
        new Date().toISOString().split("T")[0];

    db.all(
        `
        SELECT
            id,
            student_id,
            name,
            section,
            roll_number,
            date,
            time
        FROM attendance
        WHERE date = ?
        ORDER BY time ASC
        `, [today],
        (err, rows) => {

            if (err) {

                console.error(err);

                return res.status(500).json({
                    success: false,
                    message: "Failed to fetch attendance."
                });

            }

            res.json({
                success: true,
                date: today,
                totalPresent: rows.length,
                attendance: rows
            });

        }
    );

});

// ============================================================
// GET ALL ATTENDANCE
// ADMIN ONLY
// ============================================================

app.get("/api/attendance", requireAdmin, (req, res) => {

    db.all(
        `
        SELECT
            id,
            student_id,
            name,
            section,
            roll_number,
            date,
            time
        FROM attendance
        ORDER BY date DESC, time DESC
        `, [],
        (err, rows) => {

            if (err) {

                console.error(err);

                return res.status(500).json({
                    success: false,
                    message: "Failed to fetch attendance."
                });

            }

            res.json({
                success: true,
                attendance: rows
            });

        }
    );

});

// ============================================================
// GET TODAY'S PRESENT STUDENT NAMES
// ADMIN ONLY
// ============================================================

app.get("/api/present-students", requireAdmin, (req, res) => {

    const today =
        new Date().toISOString().split("T")[0];

    db.all(
        `
        SELECT
            student_id,
            name,
            section,
            roll_number,
            time
        FROM attendance
        WHERE date = ?
        ORDER BY time ASC
        `, [today],
        (err, rows) => {

            if (err) {

                return res.status(500).json({
                    success: false,
                    message: "Failed to get present students."
                });

            }

            res.json({
                success: true,
                date: today,
                totalPresent: rows.length,
                students: rows
            });

        }
    );

});

// ============================================================
// DELETE TODAY'S ATTENDANCE
// ADMIN ONLY
// ============================================================

app.delete("/api/attendance/today", requireAdmin, (req, res) => {

    const today =
        new Date().toISOString().split("T")[0];

    db.run(
        `
        DELETE FROM attendance
        WHERE date = ?
        `, [today],
        function(err) {

            if (err) {

                return res.status(500).json({
                    success: false,
                    message: "Failed to clear today's attendance."
                });

            }

            res.json({
                success: true,
                message: "Today's attendance cleared.",
                deleted: this.changes
            });

        }
    );

});

// ============================================================
// DEFAULT HOME PAGE
// ============================================================

app.get("/", (req, res) => {

    res.sendFile(
        path.join(__dirname, "public", "index.html")
    );

});

// ============================================================
// 404 HANDLER
// ============================================================

app.use((req, res) => {

    res.status(404).json({
        success: false,
        message: "API route not found."
    });

});

// ============================================================
// START SERVER
// ============================================================

app.listen(PORT, () => {

    console.log("");
    console.log("==============================================");
    console.log(" FACE RECOGNITION ATTENDANCE SYSTEM");
    console.log("==============================================");
    console.log(` Server running at: http://localhost:${PORT}`);
    console.log("");
    console.log(" Admin username: admin");
    console.log(" Admin password: admin123");
    console.log("==============================================");
    console.log("");

});